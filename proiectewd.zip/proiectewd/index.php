<?php

require 'config.php';
if(!empty($_SESSION["id"])){
  $id = $_SESSION["id"];
  $result = mysqli_query($conn, "SELECT * FROM tb_user1 WHERE id = $id");
  $row = mysqli_fetch_assoc($result);
}
else{
  header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
</head>

<body>

<div class="header">
  <h1>Sefora</h1>
  <p>Professional Makeup</p>
</div>

<div class="navbar">
  <a href="index.php">Home</a>
  <a href="login.php">Login</a>
  <a href="login.php">Logout</a>
  <div class="dropdown">
    <button class="dropbtn">Meniu
      <i class="fa fa-caret-down"></i>
    </button>  
    <div class="dropdown-content">
      <a href="pagina_makeup.html">Makeup</a>
      <a href="pagina_skincare.html">Skincare</a>
      <a href="pagina_hair.html">Hair</a>
    </div>
  </div>
  <a href="cart.html" class="cart-icon"  style="float:right">
    <i class="fa fa-shopping-cart" data-count="0" ></i>
    <icon-icon name="basket"></icon-icon><span class="cart-count">0</span>

  </a>
</div>  
</body>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>Makeup</h2>
      <h5>New at Sefora</h5>
      <img src="https://post.healthline.com/wp-content/uploads/2020/08/beauty-skin-care-cosmetics_thumb-1-732x549.jpg">
      <p>Dicover new makeup | From their must-have matte bronzer, to their stay-all-day setting.</p>
    </div>
    <div class="card">
      <h2>SkinCare</h2>
      <h5>New week at Sepfora</h5>
      <img src="https://images.everydayhealth.com/images/what-are-natural-skin-care-products-alt-1440x810.jpg">
      <p>It's time to love the skin you're in. Offering skincare products and treatments to suit every skin type, from sensitive and oily to combination and dry.</p>
    </div>
    <div class="card">
      <h2>Hair</h2>
      <h5>New at Sefora</h5>
      <img src="https://popshion.net/wp-content/uploads/2020/06/Gisou-all-products-review-3-scaled.jpg">
      <p>Hair products adapted to all hair needs and types - from styling out natural curls to reparing even the most damaged strands. </p>
    </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>About Us</h2>
      <img src="https://theindustry.beauty/wp-content/uploads/2023/03/Sephoramain.jpg" style="height:100px;">
      <p>A leader in prestige omni-retail, our mission at Sefora is to create a welcoming beauty shopping experience for all and inspire fearlessness in our community.</p>
    </div>
    <div class="card">
      <h3>Popular Post</h3>
      <img src="https://www.sephora.ro/dw/image/v2/BBQW_PRD/on/demandware.static/-/Library-Sites-SephoraV2/ro_RO/dwa7ac5951/novelties-pages/rare-beauty-new.jpg?sw=768&sfrm=png">
      <img src="https://hips.hearstapps.com/hmg-prod/images/tc-3-product-template-645a8db50c8da.png?crop=1.00xw:1.00xh;0,0&resize=1200:*">
      <img src="https://www.shoppingaddict.fr/blogs/media/articles/sephora/sephorafavorites/sephora-favorites-summer-essentials.jpg">
    </div>
    
  </div>
</div>

<div class="footer">
  <h2></h2>
</div>


<script src="main.js"></script>


</body>
</html>