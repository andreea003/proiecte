let carts = document.querySelectorAll('.add-cart');

let products = [
    {
        name: 'Serum',
        tag: 'serum',
        price: 8.99,
        inCart: 0
    },

    {
        name: 'Hair mask',
        tag: 'hairmask',
        price: 14.99,
        inCart: 0
    },

    {
        name: 'kit',
        tag: 'kit',
        price: 39.99,
        inCart: 0
    },

    {
        name: 'Cleanser',
        tag: 'cleanser',
        price: 9.99,
        inCart: 0
    },

    {
        name: 'Skincare kit',
        tag: 'skincarekit',
        price: 49.99,
        inCart: 0
    },

    {
        name: 'Cream',
        tag: 'cream',
        price: 29.99,
        inCart: 0
    },

    {
        name: 'Makeup set',
        tag: 'makeupset',
        price: 29.99,
        inCart: 0
    },

    {
        name: 'Brow set',
        tag: 'browset',
        price: 20.00,
        inCart: 0
    },

    {
        name: 'Palette',
        tag: 'palette',
        price: 39.99,
        inCart: 0
    }

];

for (let i = 0; i < carts.length; i++) {
    carts[i].addEventListener('click', (event) => {
      let productID = event.target.getAttribute('data-product-id');
      console.log("ProductID" + productID);
      let product = products[productID-1]
      if (product) {
        cartNumbers(product);
        console.log(i+ " lungime: " +  carts.length);
        totalCost(product);
        displayCartItems();
      }
      else {
        console.log("nu a gasit produsul");
      }
    });
  }

function onLoadCartNumbers() {
  let productNumbers = localStorage.getItem('cartNumbers');
  let totalCost = localStorage.getItem('totalCost');
  let cartCountElement = document.querySelector('.cart-count');
  let totalCostElement = document.querySelector('.total-cost');

  if (productNumbers) {
    cartCountElement.textContent = productNumbers;
  }

  if (totalCost) {
    totalCostElement.textContent = 'Total: $' + parseFloat(totalCost).toFixed(2);
  }
}

function cartNumbers(product) {
  let productNumbers = localStorage.getItem('cartNumbers');

  productNumbers = parseInt(productNumbers) || 0;

  localStorage.setItem('cartNumbers', productNumbers + 1);
  document.querySelector('.cart-count').textContent = productNumbers + 1;

  setItems(product);
}

function setItems(product) {
  let cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);

  if (cartItems != null) {
    if (cartItems[product.tag] == undefined) {
      cartItems[product.tag] = product;
      cartItems[product.tag].inCart = 1;
    } else {
      cartItems[product.tag].inCart += 1;
    }
  } else {
    product.inCart = 1;
    cartItems = {
      [product.tag]: product
    };
  }

  localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(product) {
  let cartCost = localStorage.getItem('totalCost');

  if (cartCost != null) {
    cartCost = parseFloat(cartCost);
    localStorage.setItem("totalCost", cartCost + product.price);
  } else {
    localStorage.setItem("totalCost", product.price);
  }

  document.querySelector('.total-cost').textContent = 'Total: $' + (cartCost ? (cartCost + product.price) : product.price).toFixed(2);
}

function displayCartItems() {
  let cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);

  let cartItemsContainer = document.querySelector('.cart-items tbody');
  cartItemsContainer.innerHTML = '';

  if (cartItems && Object.keys(cartItems).length > 0) {
    Object.values(cartItems).forEach(product => {
      let cartItem = document.createElement('tr');
      cartItem.innerHTML = `
        <td>${product.name}</td>
        <td>${product.inCart}</td>
        <td>$${product.price.toFixed(2)}</td>
      `;
      cartItemsContainer.appendChild(cartItem);
    });
  } else {
    // Coșul de cumpărături este gol
    cartItemsContainer.innerHTML = '<tr><td colspan="3" class="empty-cart">Cosul de cumparaturi este gol</td></tr>';
  }
}

let resetButton = document.querySelector('.reset-cart');

resetButton.addEventListener('click', () => {
  localStorage.removeItem('cartNumbers');
  localStorage.removeItem('productsInCart');
  localStorage.removeItem('totalCost');
  document.querySelector('.cart-count').textContent = 0;
  document.querySelector('.total-cost').textContent = 'Total: $0.00';

  // Actualizare vizualizare coș de cumpărături
  displayCartItems();
});

onLoadCartNumbers();
displayCartItems();
