package vizualizatorSDA;

import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {

		GUI gui = new GUI();
		gui.setVisible(true);
		gui.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

}
