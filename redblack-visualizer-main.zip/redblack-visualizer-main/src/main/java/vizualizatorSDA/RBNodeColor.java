package vizualizatorSDA;

public enum RBNodeColor {
	RED,
	BLACK
}
