<?php
	$conn = new mysqli('localhost', 'root', '', 'alphaware');
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}

?>
