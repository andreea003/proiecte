<?php



require 'config.php';

// if(!empty($_SESSION["id"])){

//   header("Location: index.php");

// }

if(isset($_POST["submit"])){

  $usernameemail = $_POST["usernameemail"];

  $password = $_POST["password"];

  $result = mysqli_query($conn, "SELECT * FROM tb_user WHERE username = '$usernameemail' OR email = '$usernameemail'");

  $row = mysqli_fetch_assoc($result);

  if(mysqli_num_rows($result) > 0){

    if($password == $row['password']){

      $_SESSION["login"] = true;

      $_SESSION["id"] = $row["id"];

      header("Location: index.php");

    }

    else{

      echo

      "<script> alert('Wrong Password'); </script>";

    }

  }

  else{

    echo

    "<script> alert('User Not Registered'); </script>";

  }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>


<body>  
  <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>

    <div class="container">
      

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
        
      <button type="submit" name="submit">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>

    <div class="container" style="background-color:#f1f1f1; padding-top: 16px">
    <p>Don't have an account? <a href="register.php">Register</a></p>
  </div>
  </form>
</div>
<script src="script.js"></script>

</body>
</html>
