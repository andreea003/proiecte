<?php

session_start();

$conn = mysqli_connect("localhost", "root", "", "pi") or die ('Connection failed');
?>