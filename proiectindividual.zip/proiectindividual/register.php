<?php

require 'config.php';

// if(!empty($_SESSION["id"])){

//   header("Location: index.php");

// }

if(isset($_POST["submit"])){

  $name = $_POST["name"];

  $username = $_POST["username"];

  $email = $_POST["email"];

  $password = $_POST["password"];

  $confirmpassword = $_POST["confirmpassword"];

  $duplicate = mysqli_query($conn, "SELECT * FROM tb_user1 WHERE username = '$username' OR email = '$email'");

  if(mysqli_num_rows($duplicate) > 0){

    echo

    "<script> alert('Username or Email Has Already Taken'); </script>";

  }

  else{

    if($password == $confirmpassword){

      $query = "INSERT INTO tb_user1 VALUES('','$name','$username','$email','$password')";

      mysqli_query($conn, $query);

      echo

      "<script> alert('Registration Successful'); </script>";

    }

    else{

      echo

      "<script> alert('Password Does Not Match'); </script>";

    }

  }

}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>


    <div class="container">
    
      <label for="name"><b>Name</b></label>
      <input type="text" placeholder="Enter name" name="name" required>

      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
      
      <label for="email"><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="email" required>
        
      <button type="submit" name="register">Register</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
  

  <div class="container" style="background-color:#f1f1f1; padding-top: 16px">
    <p>Already have an account? <a href="login.php">Login</a></p>
  </div>
</div>
<script src="script.js"></script>
</body>
</html>
